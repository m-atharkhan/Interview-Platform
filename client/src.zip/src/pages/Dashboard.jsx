import { useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { FaVideo, FaSignOutAlt, FaPlus, FaBook } from "react-icons/fa";
import { FiSun, FiMoon, FiArrowRight, FiGrid } from "react-icons/fi";
import useAuth from "../hooks/useAuth";
import api from "../api/axios";
import ThemeToggle from "../components/ThemeToggle";

export default function Dashboard() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const [roomId, setRoomId] = useState("");

  if (loading) return null;

  const createInterview = async () => {
    try {
      const { data } = await api.post("/interviews/create");
      toast.success("Interview created");
      navigate(`/interview/${data.roomId}`);
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to create interview");
    }
  };

  const joinInterview = () => {
    if (!roomId.trim()) { toast.error("Enter a valid room ID"); return; }
    navigate(`/interview/${roomId}`);
  };

  const logout = async () => {
    try {
      await api.post("/auth/logout");
      toast.success("Logged out");
      navigate("/login");
    } catch {
      toast.error("Logout failed");
    }
  };

  const initials = user?.name
    ? user.name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2)
    : "?";

  return (
    <div className="min-h-screen bg-light-bg dark:bg-dark-bg text-light-text dark:text-dark-text">

      {/* HEADER */}
      <header className="sticky top-0 z-10 bg-light-card dark:bg-dark-card border-b border-light-border dark:border-dark-border">
        <div className="max-w-5xl mx-auto px-6 h-[60px] flex items-center justify-between">

          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded-lg bg-amu-primary flex items-center justify-center">
              <FiGrid size={13} className="text-white" />
            </div>
            <span className="text-[15px] font-semibold tracking-tight">
              AMU Interview Platform
            </span>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <ThemeToggle />
            <button
              onClick={logout}
              className="flex items-center gap-2 text-[13px] font-medium bg-amu-primary hover:bg-amu-secondary text-white px-4 py-2 rounded-lg transition-colors"
            >
              <FaSignOutAlt size={12} />
              Logout
            </button>
          </div>

        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-10">

        {/* HERO BANNER */}
        <div className="relative overflow-hidden bg-amu-primary rounded-2xl px-8 py-7 mb-8 flex items-center justify-between">
          {/* Decorative rings */}
          <div className="absolute -right-10 -top-10 w-44 h-44 rounded-full border-[28px] border-white/5 pointer-events-none" />
          <div className="absolute right-12 -bottom-14 w-36 h-36 rounded-full border-[20px] border-white/[0.04] pointer-events-none" />

          <div className="relative">
            <p className="text-[11px] uppercase tracking-widest text-white/50 mb-1">
              Welcome back
            </p>
            <h2 className="text-[22px] font-semibold text-white leading-tight">
              {user?.name}
              <span className="text-[14px] font-normal text-white/60 ml-2">
                — {user?.role}
              </span>
            </h2>
            <p className="text-[12px] text-white/50 mt-1">{user?.email}</p>

            {/* Stats row */}
            <div className="flex items-center gap-6 mt-5">
              {[
                { label: "Interviews", value: "—" },
                { label: "Questions", value: "—" },
                { label: "Candidates", value: "—" },
              ].map((s, i) => (
                <div key={i} className="flex items-center gap-6">
                  {i > 0 && <div className="w-px h-6 bg-white/10" />}
                  <div>
                    <p className="text-[17px] font-semibold text-white">{s.value}</p>
                    <p className="text-[11px] text-white/50">{s.label}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Avatar */}
          <div className="relative w-14 h-14 rounded-full bg-white/15 flex items-center justify-center text-white text-[18px] font-semibold flex-shrink-0">
            {initials}
          </div>
        </div>

        {/* SECTION LABEL */}
        <p className="text-[11px] font-medium uppercase tracking-widest text-light-text/40 dark:text-dark-text/40 mb-4">
          Quick actions
        </p>

        {/* ACTION CARDS */}
        {user?.role === "interviewer" && (
          <div className="grid md:grid-cols-3 gap-4 mb-8">

            {/* Create Interview */}
            <div className="bg-light-card dark:bg-dark-card border border-light-border dark:border-dark-border rounded-xl p-5 flex flex-col gap-3 hover:border-amu-accent/50 transition-colors">
              <div className="w-9 h-9 rounded-lg bg-amu-primary/10 flex items-center justify-center">
                <FaVideo size={14} className="text-amu-primary" />
              </div>
              <div>
                <h3 className="text-[14px] font-semibold mb-1">Create interview</h3>
                <p className="text-[12px] text-light-text/50 dark:text-dark-text/50 leading-relaxed">
                  Start a new session and invite candidates to a live coding room.
                </p>
              </div>
              <button
                onClick={createInterview}
                className="mt-auto flex items-center gap-2 self-start text-[12px] font-medium bg-amu-primary hover:bg-amu-secondary text-white px-4 py-2 rounded-lg transition-colors"
              >
                Create <FiArrowRight size={11} />
              </button>
            </div>

            {/* Add Question */}
            <div className="bg-light-card dark:bg-dark-card border border-light-border dark:border-dark-border rounded-xl p-5 flex flex-col gap-3 hover:border-amu-accent/50 transition-colors">
              <div className="w-9 h-9 rounded-lg bg-amu-primary/10 flex items-center justify-center">
                <FaPlus size={14} className="text-amu-primary" />
              </div>
              <div>
                <h3 className="text-[14px] font-semibold mb-1">Add question</h3>
                <p className="text-[12px] text-light-text/50 dark:text-dark-text/50 leading-relaxed">
                  Create new coding problems for your question bank.
                </p>
              </div>
              <button
                onClick={() => navigate("/questions/create")}
                className="mt-auto flex items-center gap-2 self-start text-[12px] font-medium bg-amu-primary hover:bg-amu-secondary text-white px-4 py-2 rounded-lg transition-colors"
              >
                Add <FiArrowRight size={11} />
              </button>
            </div>

            {/* Question Bank */}
            <div className="bg-light-card dark:bg-dark-card border border-light-border dark:border-dark-border rounded-xl p-5 flex flex-col gap-3 hover:border-amu-accent/50 transition-colors">
              <div className="w-9 h-9 rounded-lg bg-amu-primary/10 flex items-center justify-center">
                <FaBook size={14} className="text-amu-primary" />
              </div>
              <div>
                <h3 className="text-[14px] font-semibold mb-1">Question bank</h3>
                <p className="text-[12px] text-light-text/50 dark:text-dark-text/50 leading-relaxed">
                  Browse, edit, and manage all your interview problems.
                </p>
              </div>
              <button
                onClick={() => navigate("/questions")}
                className="mt-auto flex items-center gap-2 self-start text-[12px] font-medium bg-amu-primary hover:bg-amu-secondary text-white px-4 py-2 rounded-lg transition-colors"
              >
                Open <FiArrowRight size={11} />
              </button>
            </div>

          </div>
        )}

        {/* JOIN INTERVIEW */}
        <p className="text-[11px] font-medium uppercase tracking-widest text-light-text/40 dark:text-dark-text/40 mb-4">
          Join a session
        </p>

        <div className="bg-light-card dark:bg-dark-card border border-light-border dark:border-dark-border rounded-xl p-5">
          <h3 className="text-[14px] font-semibold mb-1">Join interview</h3>
          <p className="text-[12px] text-light-text/50 dark:text-dark-text/50 mb-4">
            Enter the room ID shared with you by the interviewer.
          </p>
          <div className="flex gap-3">
            <input
              placeholder="Room ID — e.g. AMU-8821"
              value={roomId}
              onChange={(e) => setRoomId(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && joinInterview()}
              className="
                flex-1 px-4 py-2.5 rounded-lg text-[13px]
                bg-light-bg dark:bg-dark-bg
                border border-light-border dark:border-dark-border
                text-light-text dark:text-dark-text
                placeholder:text-light-text/30 dark:placeholder:text-dark-text/30
                outline-none focus:ring-2 focus:ring-amu-primary/40 focus:border-amu-primary
                transition-all
              "
            />
            <button
              onClick={joinInterview}
              className="flex items-center gap-2 bg-amu-primary hover:bg-amu-secondary text-white px-5 py-2.5 rounded-lg text-[13px] font-medium transition-colors"
            >
              Join <FiArrowRight size={13} />
            </button>
          </div>
        </div>

      </main>
    </div>
  );
}